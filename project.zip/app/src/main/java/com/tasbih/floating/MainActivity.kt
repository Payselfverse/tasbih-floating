package com.tasbih.floating

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {

    private lateinit var status: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val pad = (24 * resources.displayMetrics.density).toInt()
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(pad, pad * 2, pad, pad)
            setBackgroundColor(Color.WHITE)
        }

        val title = TextView(this).apply {
            text = "Tasbih Mengambang"
            textSize = 26f
            setTextColor(Color.parseColor("#0F766E"))
            gravity = Gravity.CENTER
        }

        val help = TextView(this).apply {
            text = "Ketuk lingkaran = +1\nTekan lama = reset\nSeret = pindahkan\nGetar panjang tiap kelipatan 33"
            textSize = 15f
            setTextColor(Color.DKGRAY)
            gravity = Gravity.CENTER
            setPadding(0, pad, 0, pad)
        }

        status = TextView(this).apply {
            textSize = 15f
            gravity = Gravity.CENTER
            setPadding(0, 0, 0, pad)
        }

        val permBtn = Button(this).apply {
            text = "1. Izinkan tampil di atas aplikasi lain"
            setOnClickListener {
                startActivity(
                    Intent(
                        Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:$packageName")
                    )
                )
            }
        }

        val startBtn = Button(this).apply {
            text = "2. Mulai tasbih mengambang"
            setOnClickListener {
                if (!Settings.canDrawOverlays(this@MainActivity)) {
                    updateStatus()
                } else {
                    startForegroundService(Intent(this@MainActivity, FloatingService::class.java))
                }
            }
        }

        val stopBtn = Button(this).apply {
            text = "Hentikan"
            setOnClickListener {
                stopService(Intent(this@MainActivity, FloatingService::class.java))
            }
        }

        root.addView(title)
        root.addView(help)
        root.addView(status)
        root.addView(permBtn)
        root.addView(startBtn)
        root.addView(stopBtn)
        setContentView(root)

        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }
    }

    override fun onResume() {
        super.onResume()
        updateStatus()
    }

    private fun updateStatus() {
        val ok = Settings.canDrawOverlays(this)
        status.text = if (ok) "Izin tampil di atas aplikasi lain: aktif" else "Izin belum aktif, tekan tombol 1 dulu"
        status.setTextColor(if (ok) Color.parseColor("#15803D") else Color.parseColor("#B91C1C"))
    }
}
